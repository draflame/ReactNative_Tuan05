import { StyleSheet, Text, View, TouchableOpacity, Image,FlatList,TextInput } from 'react-native';
import {MaterialIcons,FontAwesome,Entypo,Ionicons,Feathern} from '@expo/vector-icons';
import AntDesign from '@expo/vector-icons/AntDesign';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

import FlatListItem2 from '../components/FlatListItem2'
// Top of the file
const anh1 = require('../assets/giacchuyen1.png');
const anh2 = require('../assets/daynguon1.png');
const anh3 = require('../assets/dauchuyendoipsps21.png');
const anh4 = require('../assets/dauchuyendoi1.png');
const anh5 = require('../assets/carbusbtops21.png');
const anh6 = require('../assets/daucam1.png');

export default function FlatListScreen(){
  const items=[
    {
      id: 1,
      name: "Cap chuyen tu cong USB sang PS2",
      img:anh1
    },
    {
      id: 2,
     name: "Cap chuyen tu cong USB sang PS2",
      img:anh2
    },
    {
      id: 3,
      name: "Cap chuyen tu cong USB sang PS2",
      img:anh3
    },
    {
      id: 4,
      name: "Cap chuyen tu cong USB sang PS2",
      img:anh4
    },
    {
      id: 5,
      name: "Cap chuyen tu cong USB sang PS2",
      img:anh5
    },
    {
      id: 6,
      name: "Cap chuyen tu cong USB sang PS2",
      img:anh6
    },
  ]

  return(
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <View style={styles.searchContainer}>
          <Ionicons name="search" size={18} color="#888" style={styles.searchIcon} />
          <TextInput
            placeholder="Tìm kiếm..."
            placeholderTextColor="#888"
            style={styles.searchInput}
          />
        </View>

          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="cart" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="ellipsis-horizontal-outline" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={{flex: 1}}>
          <FlatList
            data={items}
            renderItem={({ item }) => <FlatListItem2 item={item} />}
            keyExtractor={(item) => item.id.toString()
            }
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            numColumns={2}
          />

        </View>
        <View style={styles.header}>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="remove-outline" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="home" size={24} color="#fff" />
          </TouchableOpacity>
            
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="return-up-back-outline" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  header: {
    backgroundColor: 'blue',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    alignItems: 'center',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  note: {
    backgroundColor: '#c5c5c5',
    padding: 10,
  },
  searchContainer: {
    width: 200,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 8,
    paddingHorizontal: 10,
    marginHorizontal: 10,
    height: 36,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
 
    backgroundColor: "#fff",
    borderRadius: 8,
    paddingHorizontal: 10,
    marginHorizontal: 10,
    height: 36,
    color: "#000",
  },
});