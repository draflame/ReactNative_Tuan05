import { StyleSheet, Text, View, TouchableOpacity, Image,FlatList } from 'react-native';
import {MaterialIcons,FontAwesome,Entypo,Ionicons,Feathern} from '@expo/vector-icons';
import AntDesign from '@expo/vector-icons/AntDesign';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

import FlatListItem1 from '../components/FlatListItem1'
// Top of the file
const ca_nau_lau = require('../assets/ca_nau_lau.png');
const do_choi_dang_mo_hinh = require('../assets/do_choi_dang_mo_hinh.png');
const ga_bo_toi = require('../assets/ga_bo_toi.png');
const hieu_long_con_tre = require('../assets/hieu_long_con_tre.png');
const lanh_dao_gian_don = require('../assets/lanh_dao_gian_don.png');
const trump1 = require('../assets/trump1.png');
const xa_can_cau = require('../assets/xa_can_cau.png');

export default function FlatListScreen(){
  const items=[
    {
      id: 1,
      name: "Ca nau lau mi mini,..",
      shop: "Devang",
      img:ca_nau_lau
    },
    {
      id: 2,
      name: "1KG KHO GA BO TOI,...",
      shop: "LTD Food",
      img:ga_bo_toi
    },
    {
      id: 3,
      name: "Xe can cau da nang",
      shop: "The gioi do choi",
      img:xa_can_cau
    },
    {
      id: 4,
      name: "Do choi dang mo hinh",
      shop: "The gioi do choi",
      img:do_choi_dang_mo_hinh
    },
    {
      id: 5,
      name: "Lanh dao gian don",
      shop: "Minh Long Book",
      img:lanh_dao_gian_don
    },
    {
      id: 6,
      name: "Hieu long con tre",
      shop: "Minh Long Book",
      img:hieu_long_con_tre
    },
    {
      id: 7,
      name: "Donald Trump thien tai",
      shop: "Minh Long Book",
      img:trump1
    },
  ]

  return(
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
            <Text style={{color:"#fff"}}>Chat</Text>
            <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="cart" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={{backgroundColor: "#c5c5c5", padding:5}}>
          <Text>Ban co thac mac voi san pham moi xem. Dung ngan ngai chat voi shop!</Text>
        </View>
        <View style={{flex: 1}}>
          <FlatList
            data={items}
            renderItem={({ item }) => <FlatListItem1 item={item} />}
            keyExtractor={(item) => item.id.toString()
            }
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
          />

        </View>
        <View style={styles.header}>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="remove-outline" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="home" size={24} color="#fff" />
          </TouchableOpacity>
            
          <TouchableOpacity style={{color:"white"}}>
            <Ionicons name="return-up-back-outline" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  header: {
    backgroundColor: 'blue',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    alignItems: 'center',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  note: {
    backgroundColor: '#c5c5c5',
    padding: 10,
  },
});