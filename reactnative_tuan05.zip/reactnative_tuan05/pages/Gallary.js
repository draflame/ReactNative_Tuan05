import React, { useState, useEffect } from "react"
import {
  View,
  Text,
  Image,
  FlatList,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"

export default function Gallery() {
  const [images, setImages] = useState([])
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState("list") // 'list' or 'grid'

  // Fetch ảnh từ Picsum Photos
  useEffect(() => {
    const fetchImages = async () => {
      setLoading(true)
      try {
        const res = await fetch("https://picsum.photos/v2/list?page=1&limit=20")
        const data = await res.json()

        const formatted = data.map((img, index) => ({
          id: img.id,
          url: img.download_url,
          title: img.author,
          featured: index < 3,
        }))

        setImages(formatted)
      } catch (err) {
        console.error("Lỗi tải ảnh:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchImages()
  }, [])

  const featuredImages = images.filter((img) => img.featured)
  const regularImages = images.filter((img) => !img.featured)

  // Component hiển thị ảnh
  const ImageItem = ({ item, isHorizontal = false }) => (
    <View style={[styles.card, isHorizontal && { width: 200 }]}>
      <Image source={{ uri: item.url }} style={styles.image} />
      <View style={styles.overlay}>
        <Text style={styles.imageTitle}>{item.title}</Text>
      </View>
    </View>
  )

  // Horizontal List
  const HorizontalList = ({ data, title }) => (
    <View style={{ marginBottom: 20 }}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <FlatList
        data={data}
        horizontal
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <ImageItem item={item} isHorizontal />}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: 10 }}
      />
    </View>
  )

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={{ marginBottom: 20 }}>
        <Text style={styles.header}>Gallery App</Text>
        <Text style={styles.subHeader}>
          Khám phá bộ sưu tập hình ảnh đẹp từ Picsum Photos với nhiều chế độ xem
        </Text>
      </View>

      {/* Featured Images */}
      {!loading && featuredImages.length > 0 && (
        <HorizontalList data={featuredImages} title="Hình ảnh nổi bật" />
      )}

      {/* Toggle buttons */}
      <View style={styles.toggleContainer}>
        <TouchableOpacity
          style={[styles.toggleButton, viewMode === "list" && styles.activeButton]}
          onPress={() => setViewMode("list")}
        >
          <Ionicons name="list" size={16} color={viewMode === "list" ? "#fff" : "#333"} />
          <Text style={[styles.toggleText, viewMode === "list" && { color: "#fff" }]}>
            Danh sách
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.toggleButton, viewMode === "grid" && styles.activeButton]}
          onPress={() => setViewMode("grid")}
        >
          <Ionicons name="grid" size={16} color={viewMode === "grid" ? "#fff" : "#333"} />
          <Text style={[styles.toggleText, viewMode === "grid" && { color: "#fff" }]}>
            Lưới
          </Text>
        </TouchableOpacity>
      </View>

      {/* Loading */}
      {loading && <ActivityIndicator size="large" color="blue" style={{ marginVertical: 20 }} />}

      {/* Content */}
      {!loading && (
        <View style={{ marginBottom: 20 }}>
          {viewMode === "list" ? (
          <View style={{ gap: 10 }}>
            {regularImages.map((item) => (
              <ImageItem key={item.id} item={item} />
            ))}
          </View>
        ) : (
          <FlatList
            data={regularImages}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <ImageItem item={item} />}
            numColumns={2} // hiển thị 2 cột
            columnWrapperStyle={{ gap: 10 }}
            contentContainerStyle={{ gap: 10 }}
            scrollEnabled={false} // vì đã bọc trong ScrollView
          />
        )}

        </View>
      )}

      {/* Footer */}
      {!loading && (
        <View style={styles.footer}>
          <Text style={{ color: "gray" }}>Hiển thị {images.length} hình ảnh</Text>
        </View>
      )}
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#fff",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
  },
  subHeader: {
    color: "gray",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 10,
  },
  card: {
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    overflow: "hidden",
    flex: 1,
  },
  image: {
    width: "100%",
    height: 150,
    resizeMode: "cover",
  },
  overlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 6,
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  imageTitle: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  toggleContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 10,
    marginBottom: 16,
  },
  toggleButton: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    gap: 4,
  },
  activeButton: {
    backgroundColor: "#007bff",
    borderColor: "#007bff",
  },
  toggleText: {
    fontSize: 14,
    color: "#333",
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: "#ddd",
    paddingVertical: 12,
    alignItems: "center",
  },
})


