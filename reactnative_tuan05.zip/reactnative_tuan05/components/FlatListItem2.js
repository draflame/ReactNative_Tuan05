import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import {MaterialIcons,FontAwesome,Entypo,Ionicons,Feather} from '@expo/vector-icons';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

const FlatListItem2=({item})=>{
  return(
    <View style={styles.container}>
      <View style={{flex:1}}>
        <Image source={item.img} style={{ width: 150, height: 100 }} /> 
      </View>
      <Text>Cáp chuyển từ Cổng USB sang PS2...</Text>
      <View style={{flexDirection:"row", gap:5,marginVertical:5 }}>
        <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
        <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
        <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
        <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
        <View>  <Ionicons name="star" size={15} color="#c4c4c4" /></View>
        <Text>(15)</Text>
      </View>
      <View style={{flexDirection:"row", gap:5,justifyContent:"space-around"}}>
        <Text style={{fontWeight:"bold"}}>69.000 đ</Text>
        <Text style={{color:"#c4c4c4"}}>-39%</Text>
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
    // alignItems:"center"
  }
});
export default FlatListItem2