import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import {MaterialIcons,FontAwesome,Entypo,Ionicons,Feather} from '@expo/vector-icons';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

const FlatListItem1=({item})=>{
  return(
    <View style={styles.container}>
      <View style={{flex:1}}>
        <Image source={item.img} style={{ width: 100, height: 100 }} /> 
      </View>
      <View style={{padding:5, gap:10, flex:1}}>
        <Text>{item.name}</Text>
        <Text style={{color:"red", fontWeight:"bold"}}>Shop {item.shop}</Text>
      </View>
      <View style={{alignItems:"center", justifyContent:"center", flex:1}}>
        <TouchableOpacity style={{padding:10, backgroundColor:"red", color:"white",width:100, height:50, alignItems: "center", justifyContent:"center", fontWeight:"bold", borderRadius:5}}>Chat</TouchableOpacity>
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flexDirection:"row", backgroundColor: "white"
  }
});
export default FlatListItem1